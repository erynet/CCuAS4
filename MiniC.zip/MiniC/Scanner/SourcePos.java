package MiniC.Scanner;

public class SourcePos {

  public int StartCol, EndCol;
  public int StartLine, EndLine;

  public SourcePos()
  {
     StartCol = 0;
     EndCol = 0;
     StartLine = 0;
     EndLine = 0;
  }

}
