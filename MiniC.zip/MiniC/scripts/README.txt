The script in this directory shows how scripting can be used to automate
repetitive systems programming tasks. The script is for the bash command
interpreter, and it uses several standard Unix utilities to achieve its aim.
We're providing this script as an example only. You are invited to use and
possibly extend this script.  However, there are no guarantees about the
completeness of this script. Use at your own risk. ;-)
