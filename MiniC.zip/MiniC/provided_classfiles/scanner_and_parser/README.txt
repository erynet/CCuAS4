In case your scanner and parser do not work properly, you can use the class
files in this subdirectory instead. The provided classfiles are Scanner.class,
Parser.class and MiniC.class. You must use *all* classfiles, otherwise scanner
and parser won’t work.  If you use the provided classfiles, you must remove
Scanner.java, Parser.java and MiniC.java from the sources listed in the MiniC
Makefile. You should rename any existing Scanner.java, Parser.java and
MiniC.java file to end in another filename extension, e.g., *.java.old, to
prevent them from being picked up by the compiler.
